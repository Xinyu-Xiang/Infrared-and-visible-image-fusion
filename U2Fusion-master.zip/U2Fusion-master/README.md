# U2Fusion
Code of U2Fusion: a unified unsupervised image fusion network for multiple image fusion tasks, including multi-modal (VIS-IR, medical), multi-exposure and multi-focus image fusion.
