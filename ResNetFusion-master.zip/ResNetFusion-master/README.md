CODE

Jiayi Ma, Pengwei Liang, Wei Yu, Chen Chen, Xiaojie Guo, Jia Wu, and Junjun Jiang. "Infrared and visible image fusion via detail preserving adversarial learning", Information Fusion, 54, pp. 85-98, Feb. 2020.
