# SMFuse
The code of “SMFuse: Multi-focus Image Fusion via Self-supervised Mask-optimization”
#### To train :<br>
Run "CUDA_VISIBLE_DEVICES=0 python main.py" to train the network.

#### To test :<br>
Run "CUDA_VISIBLE_DEVICES=0 python test_one_image.py" to test the network.
